import { Component, OnInit, Input } from '@angular/core';
import { dashboard } from '../../dashboard.model';
import { ModalController } from '@ionic/angular';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-dataplan',
  templateUrl: './dataplan.component.html',
  styleUrls: ['./dataplan.component.scss'],
})
export class DataplanComponent implements OnInit {
  @Input() selectedPlace: dashboard;

 
  constructor(private modelCtrl:ModalController) { }

  ngOnInit() {}
  onCancel() {
    this.modelCtrl.dismiss(null, 'cancel');
  
  }
  onBuyRecharge(form: NgForm){
    if(!form.valid){
      return;
    }
  this.modelCtrl.dismiss(
    {
    RechargeData:
  {
    network_select:   form.value['network_select'],
    data_select:           form.value['data_select'],
    phone_number:     form.value['phone_number']
  }
  }, 'confirm');
  
  }

}
