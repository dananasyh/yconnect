import { Injectable } from '@angular/core';
import { dashboard } from './dashboard.model';
import { AuthService } from '../auth/auth.service';
import { BehaviorSubject } from 'rxjs';
import {take, map, tap, delay} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DashboardService {
private _dashoarData = new BehaviorSubject<dashboard[]>([
  new dashboard('d1',
  'Wallet Balance',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScYa_HjIvEh5vMPyHOAba32rjaC6Ys9gDv5pGhzYG9ZLweKXb0hw&s',
  'buy mtn,airtel and 9Mobile recharge card cheaply',
 
  'abc'),
  new dashboard(
    'd2',
    'Buy Recharge',
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScYa_HjIvEh5vMPyHOAba32rjaC6Ys9gDv5pGhzYG9ZLweKXb0hw&s',
    'Cheap Recharge for (MTN,Glo,Airtime & 9Mobile)',
     'def'
     ),
  new dashboard(
    'd3',
  'Buy Data Plan',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScYa_HjIvEh5vMPyHOAba32rjaC6Ys9gDv5pGhzYG9ZLweKXb0hw&s',
  'Cheap Internet data (MTN,Glo,Airtime & 9Mobile)',
   'ghi')
]);

get dashboardData(){
  return this._dashoarData.asObservable();
}
constructor(private authService:AuthService) { }

getDataplanId(id: string){
  return this._dashoarData.pipe(take(1), map(dashboard => {
    return {...dashboard.find(
      dp => { return dp.id === id; }) 
    }}
  ))
}

addDashboardData(title: string, description: string) {
  const newdashboard = new dashboard(
    Math.random().toString(), 
    title,
    description,
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScYa_HjIvEh5vMPyHOAba32rjaC6Ys9gDv5pGhzYG9ZLweKXb0hw&s',
    this.authService.userId);
  return this._dashoarData.pipe(take(1), delay(1000), tap(dashdata =>{

      this._dashoarData.next(dashdata.concat(newdashboard))
    
  }));
   
}
updateDashboardData(dataplanId: string, title:string, description: string){
return this._dashoarData.pipe(
  take(1),
 delay(1000),
tap(dashoarData =>{
  const updateDashboardDataIndex = dashoarData.findIndex(dd =>dd.id === dataplanId);
  const updateDashboard = [...dashoarData];
  const olddashData = updateDashboard[updateDashboardDataIndex];
  updateDashboard[updateDashboardDataIndex] = new dashboard(
    olddashData.id,
     title,
      description,
       olddashData.imgUrl,
        olddashData.userId);
  this._dashoarData.next(updateDashboard);
}))
}
}
