import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EditDataplanPage } from './edit-dataplan.page';

const routes: Routes = [
  {
    path: '',
    component: EditDataplanPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EditDataplanPageRoutingModule {}
