import { Component, OnInit, OnDestroy } from '@angular/core';
import { dashboard } from '../dashboard.model';
import { DashboardService } from '../dashboard.service';
import { RechargeComponent } from './recharge/recharge.component';
import { ModalController } from '@ionic/angular';
import { DataplanComponent } from './dataplan/dataplan.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dashboards',
  templateUrl: './dashboards.page.html',
  styleUrls: ['./dashboards.page.scss'],
})
export class DashboardsPage implements OnInit, OnDestroy {
loadeddata: dashboard[];
ishidden = false;
private dashDataSubscription: Subscription
  constructor(private dashboardService: DashboardService, private modelCtrl: ModalController) { }

  ngOnInit() {
 this.dashDataSubscription = this.dashboardService.dashboardData.subscribe(dashboard =>{
   this.loadeddata = dashboard
 });
  }
  onBuyRecharge(id: string){
    this.modelCtrl.create(
      {
        component: RechargeComponent, componentProps:{selectedPlace: this.loadeddata.find(p =>
          p.id === id)}
      }).then(modelEl =>
        {
          modelEl.present();
         return modelEl.onDidDismiss();
        }).then(resData =>{
          console.log(resData.data, resData.role);
          if(resData.role === 'confirm'){
            console.log('BOOKED!!');
          }
          
        })
      }

      onBuyDataplan(id: string) {
        this.modelCtrl.create(
          {
            component: DataplanComponent, componentProps:{selectedPlace: this.loadeddata.find(p =>
              p.id === id)}
          }).then(modelEl =>
            {
              modelEl.present();
             return modelEl.onDidDismiss();
            }).then(resData =>{
              console.log(resData.data, resData.role);
              if(resData.role === 'confirm'){
                console.log('BOOKED!!');
              }
              
            })
  }
ngOnDestroy(){
  if(this.dashDataSubscription){
    this.dashDataSubscription.unsubscribe()
  }
}
}