import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DataplanPageRoutingModule } from './dataplan-routing.module';

import { DataplanPage } from './dataplan.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DataplanPageRoutingModule
  ],
  declarations: [DataplanPage]
})
export class DataplanPageModule {}
