import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { NewDataplanPage } from './new-dataplan.page';

describe('NewDataplanPage', () => {
  let component: NewDataplanPage;
  let fixture: ComponentFixture<NewDataplanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewDataplanPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(NewDataplanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
