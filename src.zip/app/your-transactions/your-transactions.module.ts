import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { YourTransactionsPageRoutingModule } from './your-transactions-routing.module';

import { YourTransactionsPage } from './your-transactions.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    YourTransactionsPageRoutingModule
  ],
  declarations: [YourTransactionsPage]
})
export class YourTransactionsPageModule {}
