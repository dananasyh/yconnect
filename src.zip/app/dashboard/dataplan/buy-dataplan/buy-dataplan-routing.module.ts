import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BuyDataplanPage } from './buy-dataplan.page';

const routes: Routes = [
  {
    path: '',
    component: BuyDataplanPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BuyDataplanPageRoutingModule {}
