import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BuyDataplanPageRoutingModule } from './buy-dataplan-routing.module';

import { BuyDataplanPage } from './buy-dataplan.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BuyDataplanPageRoutingModule
  ],
  declarations: [BuyDataplanPage]
})
export class BuyDataplanPageModule {}
