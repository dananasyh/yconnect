import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EditDataplanPage } from './edit-dataplan.page';

describe('EditDataplanPage', () => {
  let component: EditDataplanPage;
  let fixture: ComponentFixture<EditDataplanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDataplanPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EditDataplanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
