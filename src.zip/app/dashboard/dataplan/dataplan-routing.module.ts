import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DataplanPage } from './dataplan.page';

const routes: Routes = [
  {
    path: '',
    component: DataplanPage
  },
  {
    path: 'new-dataplan',
    loadChildren: () => import('./new-dataplan/new-dataplan.module').then( m => m.NewDataplanPageModule)
  },
  {
    path: 'edit-dataplan',
    loadChildren: () => import('./edit-dataplan/edit-dataplan.module').then( m => m.EditDataplanPageModule)
  },
  {
    path: 'buy-dataplan',
    loadChildren: () => import('./buy-dataplan/buy-dataplan.module').then( m => m.BuyDataplanPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DataplanPageRoutingModule {}
