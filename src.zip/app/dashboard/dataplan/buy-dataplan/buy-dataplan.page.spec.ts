import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BuyDataplanPage } from './buy-dataplan.page';

describe('BuyDataplanPage', () => {
  let component: BuyDataplanPage;
  let fixture: ComponentFixture<BuyDataplanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyDataplanPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BuyDataplanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
