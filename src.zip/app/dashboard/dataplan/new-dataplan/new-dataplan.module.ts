import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewDataplanPageRoutingModule } from './new-dataplan-routing.module';

import { NewDataplanPage } from './new-dataplan.page';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    IonicModule,
    NewDataplanPageRoutingModule
  ],
  declarations: [NewDataplanPage]
})
export class NewDataplanPageModule {}
