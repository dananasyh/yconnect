import { Component, OnInit, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { dashboard } from '../../dashboard.model';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-recharge',
  templateUrl: './recharge.component.html',
  styleUrls: ['./recharge.component.scss'],
})
export class RechargeComponent implements OnInit {
  @Input() selectedPlace: dashboard;

 
  constructor(private modelCtrl:ModalController) { }

  ngOnInit() {}
  onCancel() {
    this.modelCtrl.dismiss(null, 'cancel');
  
  }
  onBuyRecharge(form: NgForm){
    if(!form.valid){
      return;
    }
  this.modelCtrl.dismiss(
    {
    RechargeData:
  {
    network_select:   form.value['network_select'],
    amount:           +form.value['amount'],
    phone_number:     +form.value['phone_number']
  }
  }, 'confirm');
  
  }
}
