import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DashboardService } from '../../dashboard.service';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-new-dataplan',
  templateUrl: './new-dataplan.page.html',
  styleUrls: ['./new-dataplan.page.scss'],
})
export class NewDataplanPage implements OnInit {
form: FormGroup
  constructor(
    private dashboardService: DashboardService,
     private router:Router,
     private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.form = new FormGroup({
      title: new FormControl(null,{
        updateOn: 'blur',
        validators: [Validators.required]
      }),
      describtions:  new FormControl(null,{
        updateOn: 'blur',
        validators: [Validators.required, Validators.maxLength(180)]
      })
    })
  }
  onCreatePlan(){
    if(!this.form.valid){
      return;
    }
    this.loadingCtrl.create({ keyboardClose: true, message: 'Creatung data...'
    }).then(loadingEl =>{
      loadingEl.present();
      this.dashboardService.addDashboardData(
        this.form.value.title, 
        this.form.value.describtions ).subscribe(()=>{
          loadingEl.dismiss();
          this.form.reset();
        this.router.navigate(['/dashboard/tabs/dataplan']);
        });
        
    });
    
  }

}
