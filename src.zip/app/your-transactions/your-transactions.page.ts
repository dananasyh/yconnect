import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-your-transactions',
  templateUrl: './your-transactions.page.html',
  styleUrls: ['./your-transactions.page.scss'],
})
export class YourTransactionsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
