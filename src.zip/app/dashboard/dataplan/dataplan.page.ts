import { Component, OnInit, OnDestroy } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { dashboard } from '../dashboard.model';
import { ActivatedRoute, Router } from '@angular/router';
import { IonItemSliding } from '@ionic/angular';
import {Subscription} from 'rxjs'

@Component({
  selector: 'app-dataplan',
  templateUrl: './dataplan.page.html',
  styleUrls: ['./dataplan.page.scss'],
})
export class DataplanPage implements OnInit, OnDestroy {
dataplan: dashboard[];
private dashboardSubscrip: Subscription
  constructor(private dashboardService: DashboardService, private router: Router) { }

  ngOnInit() {
  this.dashboardSubscrip = this.dashboardService.dashboardData.subscribe(dashData =>{
    this.dataplan = dashData
   });
  }

  onEdit(dataplanId: string, itemSlide:IonItemSliding){
    itemSlide.close();
    this.router.navigate(['/','dashboard','tabs','dataplan','edit-dataplan', dataplanId])
  }
  onDelete(dataplanId: string, itemSlide:IonItemSliding) {
    itemSlide.close();
    console.log('deleted item');
  }
  getDummyDate(){
   return new Date()
  }

  ngOnDestroy(){
   if(this.dashboardSubscrip){
    this.dashboardSubscrip.unsubscribe();
   }
  }
}

