import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { EditDataplanPageRoutingModule } from './edit-dataplan-routing.module';

import { EditDataplanPage } from './edit-dataplan.page';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    IonicModule,
    EditDataplanPageRoutingModule
  ],
  declarations: [EditDataplanPage]
})
export class EditDataplanPageModule {}
