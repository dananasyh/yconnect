export class Recharge {
   constructor( 
    id: string,
    dataplanId: string,
    userId: string,
    amount: number,
    phone_number: number,
    network_select: string
    ){}
}