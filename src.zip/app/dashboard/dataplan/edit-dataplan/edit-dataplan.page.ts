import { Component, OnInit, OnDestroy } from '@angular/core';
import { dashboard } from '../../dashboard.model';
import { DashboardService } from '../../dashboard.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-edit-dataplan',
  templateUrl: './edit-dataplan.page.html',
  styleUrls: ['./edit-dataplan.page.scss'],
})
export class EditDataplanPage implements OnInit, OnDestroy {
dataplan: dashboard;
form: FormGroup;
private dashboardSubscrip: Subscription;
  constructor(
    private dashboardService: DashboardService,
    private router:Router, 
    private activatedRoute: ActivatedRoute,
    private loadingCtrl: LoadingController) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(paramMap =>{
      if(!paramMap.has('dataplanId')) {
        return this.router.navigateByUrl('/dashboard/tabs/dataplan');
      }
     this.dashboardSubscrip = this.dashboardService.getDataplanId(paramMap.get('dataplanId')).subscribe(dashData =>
        {
          this.dataplan =  dashData;
          this.form = new FormGroup({
            title: new FormControl(this.dataplan.title,{
              updateOn: 'blur',
              validators: [Validators.required]
            }
            ),
            describtions: new FormControl(this.dataplan.description,{
              updateOn: 'blur',
              validators: [Validators.required,Validators.maxLength(180)]
            })
          })
        });
    
    })
  }
  onUpdatePlan(){
    if(!this.form.valid){
      return;
    }
    this.loadingCtrl.create({keyboardClose: true,
     message:'Updating Data...'
    }).then(loadingEl =>{
      loadingEl.present();
      this.dashboardService.updateDashboardData(
        this.dataplan.id,
        this.form.value.title,
        this.form.value.describtions
        ).subscribe(()=>{
        loadingEl.dismiss();
        this.form.reset();
        this.router.navigate(['/dashboard/tabs/dataplan']);
        })
    })

  }

  ngOnDestroy(){
    if(this.dashboardSubscrip){
      this.dashboardSubscrip.unsubscribe();
    }
  }
}
