import { Injectable } from '@angular/core';
import { Recharge } from './recharge.model';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from 'src/app/auth/auth.service';
import { take, tap, delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DashboardsService {
private _rechargeData = new BehaviorSubject<Recharge[]>([]);

get RechargeData(){
  return this._rechargeData.asObservable();
}
addRechargeData(
  dataplanId: string,
  userId: string,
  amount: number,
  phone_number: number,
  network_select: string
  ){
const newRecharge(
  Math.random().toString(),
   dataplanId,
    this.authService.userId,
     amount,
      phone_number,
     network_select);
   return this.RechargeData.pipe(
     take(1),
     delay(1000),
      tap(rechargedt =>{
       this._rechargeData.next(rechargedt.concat(newRecharge));
     }));
  }
  constructor(private authService: AuthService) { }
}
