import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-dataplan',
  templateUrl: './buy-dataplan.page.html',
  styleUrls: ['./buy-dataplan.page.scss'],
})
export class BuyDataplanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
