import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { DataplanPage } from './dataplan.page';

describe('DataplanPage', () => {
  let component: DataplanPage;
  let fixture: ComponentFixture<DataplanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataplanPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(DataplanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
