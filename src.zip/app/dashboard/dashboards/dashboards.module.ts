import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DashboardsPageRoutingModule } from './dashboards-routing.module';

import { DashboardsPage } from './dashboards.page';
import { RechargeComponent } from './recharge/recharge.component';
import { DataplanComponent } from './dataplan/dataplan.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DashboardsPageRoutingModule
  ],
  declarations: [DashboardsPage,RechargeComponent,DataplanComponent],
  entryComponents: [RechargeComponent,DataplanComponent ]
})
export class DashboardsPageModule {}
