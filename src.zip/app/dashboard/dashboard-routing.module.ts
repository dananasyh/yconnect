import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardPage } from './dashboard.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: DashboardPage,
    children: [
      {
        path: 'dashboards',
      children:[
        {
          path: '',
          loadChildren: () => import('./dashboards/dashboards.module').then( m => m.DashboardsPageModule)
        }
      ]
      },

{ 
  path: 'dataplan',
  children:[
    {
    path: '',
    loadChildren: () => import('./dataplan/dataplan.module').then( m => m.DataplanPageModule)
  },
  {
    path: 'new-dataplan',
    loadChildren: () => import ('./dataplan/new-dataplan/new-dataplan.module').then(m => m.NewDataplanPageModule)
  },
  {
    path: 'edit-dataplan/:dataplanId',
    loadChildren: () => import ('./dataplan/edit-dataplan/edit-dataplan.module').then(m => m.EditDataplanPageModule)
  },
  {
    path: ':dataplanId',
    loadChildren: () => import ('./dataplan/buy-dataplan/buy-dataplan.module').then(m => m.BuyDataplanPageModule)
  }
]
  
 
},
{
  path: '',
  redirectTo: '/dashboard/tabs/dashboards',
  pathMatch: 'full'
}
    ]
  },
  {
    path: '',
    redirectTo: '/dashboard/tabs/dashboards',
    pathMatch: 'full'
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardPageRoutingModule {}
