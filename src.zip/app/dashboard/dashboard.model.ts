export class dashboard {
  
    constructor(
        public id: string, 
        public title: string, 
        public imgUrl: string, 
        public description: string,
        public userId: string
        
        ){}
}